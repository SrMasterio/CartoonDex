package com.notipush.dex;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
